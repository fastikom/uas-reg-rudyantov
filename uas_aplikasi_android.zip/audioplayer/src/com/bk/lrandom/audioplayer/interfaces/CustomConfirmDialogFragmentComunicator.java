package com.bk.lrandom.audioplayer.interfaces;

public interface CustomConfirmDialogFragmentComunicator {
   void positiveCallback();
   void negativeCallback();
}
